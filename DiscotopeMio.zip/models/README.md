Please unzip models.zip in the project top directory.
